import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.github.piwza888.piwziapp',
  appName: 'Piwzi Intercom',
  webDir: 'www'
};

export default config;
