package io.github.piwza888.piwziapp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;

/**
 * ระบบรันเบื้องหลัง: ทำให้แอปไม่ถูกปิดตอนล็อกจอ เสียงจึงยังส่งถึงกันได้
 * และแสดงแจ้งเตือนค้างบนแถบว่า "กำลังถูกฟัง" เพื่อให้รู้ตัวเสมอ
 */
public class IntercomService extends Service {

    public static final String ACTION_START = "io.github.piwza888.piwziapp.START";
    public static final String ACTION_STOP = "io.github.piwza888.piwziapp.STOP";
    public static final String ACTION_LISTENED = "io.github.piwza888.piwziapp.LISTENED";
    public static final String EXTRA_ON = "on";

    private static final String CHANNEL_ID = "intercom_fg";
    private static final int NOTIF_ID = 4321;

    private PowerManager.WakeLock wakeLock;
    private boolean listened = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "piwzi:intercom");
        wakeLock.setReferenceCounted(false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;

        if (ACTION_STOP.equals(action)) {
            stopEverything();
            return START_NOT_STICKY;
        }

        if (ACTION_LISTENED.equals(action)) {
            boolean on = intent.getBooleanExtra(EXTRA_ON, false);
            if (on && !listened) beep();
            listened = on;
        }

        startForegroundSafely();
        if (wakeLock != null && !wakeLock.isHeld()) {
            try { wakeLock.acquire(); } catch (Exception ignored) {}
        }
        return START_STICKY;
    }

    private void startForegroundSafely() {
        Notification n = buildNotification();
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIF_ID, n,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                                | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) {
            // เผื่อบางรุ่นเข้มงวดเรื่อง type ให้ fallback แบบไม่มี type
            try { startForeground(NOTIF_ID, n); } catch (Exception ignored) {}
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) piFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, piFlags);

        String title = listened ? "🔴 อีกฝั่งกำลังฟังเสียงคุณ" : "อินเตอร์คอมพร้อมใช้งาน";
        String text = listened ? "แตะเพื่อเปิดแอป ถ้าไม่อยากให้ฟังกดล็อกไมค์"
                               : "แตะเพื่อเปิดแอป • เชื่อมต่ออยู่";

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(pi)
                .build();
    }

    private void beep() {
        try {
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90);
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 250);
        } catch (Exception ignored) {}
    }

    private void stopEverything() {
        listened = false;
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(Service.STOP_FOREGROUND_REMOVE);
        } else {
            stopForeground(true);
        }
        stopSelf();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "อินเตอร์คอม", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("แจ้งว่าแอปทำงานอยู่และสถานะการฟัง");
            ch.setShowBadge(false);
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    @Override
    public void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
