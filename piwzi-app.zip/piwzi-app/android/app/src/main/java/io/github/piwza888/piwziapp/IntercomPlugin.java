package io.github.piwza888.piwziapp;

import android.content.Intent;
import android.os.Build;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * สะพานให้โค้ดเว็บสั่งเปิด/ปิดระบบรันเบื้องหลัง และอัปเดตสถานะ "กำลังถูกฟัง"
 */
@CapacitorPlugin(name = "Intercom")
public class IntercomPlugin extends Plugin {

    @PluginMethod
    public void start(PluginCall call) {
        Intent i = new Intent(getContext(), IntercomService.class);
        i.setAction(IntercomService.ACTION_START);
        startSvc(i);
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        Intent i = new Intent(getContext(), IntercomService.class);
        i.setAction(IntercomService.ACTION_STOP);
        getContext().startService(i);
        call.resolve();
    }

    @PluginMethod
    public void setListened(PluginCall call) {
        boolean on = call.getBoolean("value", false);
        Intent i = new Intent(getContext(), IntercomService.class);
        i.setAction(IntercomService.ACTION_LISTENED);
        i.putExtra(IntercomService.EXTRA_ON, on);
        startSvc(i);
        call.resolve();
    }

    private void startSvc(Intent i) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getContext().startForegroundService(i);
        } else {
            getContext().startService(i);
        }
    }
}
